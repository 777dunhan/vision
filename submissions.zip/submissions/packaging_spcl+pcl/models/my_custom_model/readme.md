please download the checkpoint "spcl+pcl_IN100_400.pth.tar" to /packaging_spcl+pcl/models/my_custom_model/ from this site: 
https://drive.google.com/drive/folders/1PAee9wmToTb_Qo-C46ZMomz-CYvRWhvG

you may need to modify the checkpoint path at file model.py line 59, depending how you run the script